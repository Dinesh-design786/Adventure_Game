import React, { useReducer, useEffect, useCallback } from 'react';
import type { StoryPart, Scene } from '../types';
import { generateStoryScene, generateSceneImage } from '../services/geminiService';
import SceneDisplay from './SceneDisplay';
import ChoiceButtons from './ChoiceButtons';
import LoadingIndicator from './LoadingIndicator';

interface GameScreenProps {
  theme: string;
  onRestart: () => void;
}

interface GameScreenState {
  history: StoryPart[];
  currentScene: Scene | null;
  imageUrl: string;
  status: 'initializing' | 'loading' | 'playing' | 'error';
  isImageLoading: boolean;
  error: string | null;
}

type GameAction =
  | { type: 'START_LOADING' }
  | { type: 'SCENE_SUCCESS'; payload: { scene: Scene; newHistory: StoryPart[] } }
  | { type: 'IMAGE_SUCCESS'; payload: string }
  | { type: 'IMAGE_ERROR' }
  | { type: 'FETCH_ERROR'; payload: string };

const initialState: GameScreenState = {
  history: [],
  currentScene: null,
  imageUrl: '',
  status: 'initializing',
  isImageLoading: true,
  error: null,
};

function gameReducer(state: GameScreenState, action: GameAction): GameScreenState {
  switch (action.type) {
    case 'START_LOADING':
      return {
        ...state,
        status: 'loading',
        isImageLoading: true,
        imageUrl: '',
        error: null,
      };
    case 'SCENE_SUCCESS':
      return {
        ...state,
        status: 'playing',
        currentScene: action.payload.scene,
        history: action.payload.newHistory,
      };
    case 'IMAGE_SUCCESS':
      return {
        ...state,
        isImageLoading: false,
        imageUrl: action.payload,
      };
    case 'IMAGE_ERROR':
      return {
        ...state,
        isImageLoading: false,
        imageUrl: 'https://picsum.photos/1280/720?grayscale', // Placeholder on error
      };
    case 'FETCH_ERROR':
      return {
        ...state,
        status: 'error',
        error: action.payload,
      };
    default:
      return state;
  }
}

const GameScreen: React.FC<GameScreenProps> = ({ theme, onRestart }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);
  const { history, currentScene, imageUrl, status, isImageLoading, error } = state;

  const fetchScene = useCallback(async (currentHistory: StoryPart[]) => {
    dispatch({ type: 'START_LOADING' });
    try {
      const scene = await generateStoryScene(currentHistory, theme);
      const newHistory: StoryPart[] = [...currentHistory, { role: 'model', text: scene.sceneDescription }];
      dispatch({ type: 'SCENE_SUCCESS', payload: { scene, newHistory } });

      generateSceneImage(scene.imagePrompt)
        .then(url => {
            dispatch({ type: 'IMAGE_SUCCESS', payload: url });
        })
        .catch(imgError => {
            console.error(imgError);
            dispatch({ type: 'IMAGE_ERROR' });
        });

    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
      dispatch({ type: 'FETCH_ERROR', payload: errorMessage });
    }
  }, [theme]);

  useEffect(() => {
    const initialHistory: StoryPart[] = [{ role: 'user', text: `Start a new text adventure game with the theme: "${theme}"` }];
    fetchScene(initialHistory);
  }, [theme, fetchScene]);

  const handleChoice = (choice: string) => {
    const newHistory: StoryPart[] = [...history, { role: 'user', text: choice }];
    fetchScene(newHistory);
  };

  const isLoading = status === 'initializing' || status === 'loading';

  return (
    <div className="w-full flex flex-col min-h-[calc(100vh-2rem)]">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold text-cyan-400">Alien Adventures</h1>
        <button 
          onClick={onRestart}
          className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg transition-colors duration-200"
        >
          New Game
        </button>
      </div>

      <div className="bg-gray-800 rounded-lg shadow-2xl p-4 md:p-6 flex-grow flex flex-col">
        {status === 'error' && <div className="bg-red-500/20 border border-red-500 text-red-300 p-4 rounded-md mb-4">{error}</div>}
        
        {status === 'initializing' ? (
          <div className="flex-grow flex items-center justify-center">
            <LoadingIndicator message="The storyteller is imagining your world..." />
          </div>
        ) : (
          <>
            <SceneDisplay
              description={currentScene?.sceneDescription || ''}
              imageUrl={imageUrl}
              isLoading={isImageLoading}
            />
            {status === 'loading' ? (
              <div className="mt-6 flex items-center justify-center">
                <LoadingIndicator message="Crafting the next chapter..." />
              </div>
            ) : (
              <ChoiceButtons
                choices={currentScene?.choices || []}
                onChoice={handleChoice}
                disabled={isLoading || status !== 'playing'}
              />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default GameScreen;