import React from 'react';

interface ChoiceButtonsProps {
  choices: string[];
  onChoice: (choice: string) => void;
  disabled: boolean;
}

const ChoiceButtons: React.FC<ChoiceButtonsProps> = ({ choices, onChoice, disabled }) => {
  if (!choices || choices.length === 0) {
    return null;
  }
  
  return (
    <div className="mt-auto pt-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {choices.map((choice, index) => (
          <button
            key={index}
            onClick={() => onChoice(choice)}
            disabled={disabled}
            className="w-full p-4 text-left bg-cyan-700/80 hover:bg-cyan-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500"
          >
            {choice}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ChoiceButtons;