import React, { useState } from 'react';

interface StartScreenProps {
  onStart: (theme: string) => void;
}

const suggestedThemes = [
  "A xenobotanist cataloging strange flora on a newly discovered planet.",
  "First contact with a mysterious crystalline entity in deep space.",
  "Surviving as a castaway on a hostile alien world teeming with bizarre creatures.",
  "A diplomat negotiating a fragile peace treaty between warring alien factions.",
  "Exploring the derelict husk of a colossal, ancient alien starship.",
];

const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  const [theme, setTheme] = useState('');

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (theme.trim()) {
      onStart(theme.trim());
    }
  };
  
  const selectTheme = (selectedTheme: string) => {
    setTheme(selectedTheme);
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center justify-center min-h-screen animate-fadeIn">
      <h1 className="text-5xl md:text-6xl font-extrabold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-green-400 to-cyan-500">
        Alien Adventures
      </h1>
      <p className="text-lg text-gray-400 text-center mb-8">
        Craft your own journey. What world will you explore?
      </p>

      <form onSubmit={handleStart} className="w-full">
        <textarea
          value={theme}
          onChange={(e) => setTheme(e.target.value)}
          placeholder="Describe your adventure... e.g., 'A noir detective story on Mars'"
          className="w-full p-4 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-all duration-300 resize-none text-lg"
          rows={3}
        />
        <button
          type="submit"
          disabled={!theme.trim()}
          className="w-full mt-4 bg-cyan-600 hover:bg-cyan-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-bold py-3 px-6 rounded-lg text-xl transition-transform transform hover:scale-105 duration-300"
        >
          Begin Adventure
        </button>
      </form>
      
      <div className="mt-8 w-full">
        <h3 className="text-center text-gray-500 mb-4">Or choose a theme:</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {suggestedThemes.map((st, index) => (
            <button key={index} onClick={() => selectTheme(st)} className="text-left p-3 bg-gray-800/50 hover:bg-gray-700/70 rounded-md transition-colors duration-200 text-gray-300">
              {st}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StartScreen;