import React, { useState, useCallback } from 'react';
import GameScreen from './components/GameScreen';
import StartScreen from './components/StartScreen';
import { GameState } from './types';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [gameTheme, setGameTheme] = useState<string>('');
  
  const startGame = useCallback((theme: string) => {
    setGameTheme(theme);
    setGameState(GameState.PLAYING);
  }, []);

  const restartGame = useCallback(() => {
    setGameTheme('');
    setGameState(GameState.START);
  }, []);

  const renderContent = () => {
    switch (gameState) {
      case GameState.PLAYING:
        return <GameScreen theme={gameTheme} onRestart={restartGame} />;
      case GameState.START:
      default:
        return <StartScreen onStart={startGame} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-serif flex flex-col items-center justify-center p-4">
      <main className="w-full max-w-4xl mx-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;
