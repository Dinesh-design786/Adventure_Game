export enum GameState {
  START,
  PLAYING,
  GAME_OVER,
}

export interface StoryPart {
  role: 'user' | 'model';
  text: string;
}

export interface Scene {
  sceneDescription: string;
  imagePrompt: string;
  choices: string[];
}
