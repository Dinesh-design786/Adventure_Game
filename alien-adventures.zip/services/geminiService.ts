import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import type { StoryPart, Scene } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const storySceneSchema = {
  type: Type.OBJECT,
  properties: {
    sceneDescription: {
      type: Type.STRING,
      description: "A detailed, narrative description of the current scene for the player to read. This should be 1-2 paragraphs long, setting a vivid atmosphere.",
    },
    imagePrompt: {
      type: Type.STRING,
      description: "A concise, visually descriptive prompt for an AI image generator. Focus on key subjects, setting, style, and atmosphere. E.g., 'A lone cyborg scavenger sifts through glowing ruins on a desolate alien planet, dramatic lighting, synthwave aesthetic, digital art.'",
    },
    choices: {
      type: Type.ARRAY,
      description: "An array of 3 short, actionable choices for the player. Each choice should be a string representing an action the player can take.",
      items: {
        type: Type.STRING,
      },
    },
  },
  required: ["sceneDescription", "imagePrompt", "choices"],
};

export const generateStoryScene = async (history: StoryPart[], theme: string): Promise<Scene> => {
  const systemInstruction = `You are a master storyteller and game master for a dynamic text-based adventure game. Your goal is to create immersive, engaging, and coherent narratives based on the player's choices. The theme of this adventure is: '${theme}'. For each turn, you will be given the story so far and must continue it. You must respond with a JSON object that strictly adheres to the provided schema. The choices you provide should be distinct and lead to interesting outcomes.`;

  const contents = history.map(part => ({
    role: part.role,
    parts: [{ text: part.text }],
  }));

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: storySceneSchema,
        temperature: 0.8,
        topP: 0.9,
      },
    });

    const jsonText = response.text.trim();
    // Sometimes the response might be wrapped in markdown, clean it up.
    const cleanedJson = jsonText.replace(/^```json\n?/, '').replace(/```$/, '');
    const sceneData = JSON.parse(cleanedJson);
    
    // Validate that choices is an array of strings, sometimes model returns object with indices
    if(sceneData.choices && !Array.isArray(sceneData.choices)) {
        sceneData.choices = Object.values(sceneData.choices);
    }

    return sceneData as Scene;
  } catch (error) {
    console.error("Error generating story scene:", error);
    throw new Error("Failed to generate the next part of the story. The AI might be resting.");
  }
};


export const generateSceneImage = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateImages({
      model: 'imagen-3.0-generate-002',
      prompt: `${prompt}, cinematic, high detail, atmospheric`,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/jpeg',
        aspectRatio: '16:9',
      },
    });
    
    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    } else {
      throw new Error("No image was generated.");
    }
  } catch(error) {
      console.error("Error generating scene image:", error);
      throw new Error("Failed to visualize the scene. The AI artist seems to be on a break.");
  }
};
